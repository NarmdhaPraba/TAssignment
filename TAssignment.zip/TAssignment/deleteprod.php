<?php
$conn = mysqli_connect("localhost", "root", "", "product");

if (isset($_POST['product_ids'])) {
    $productIds = $_POST['product_ids'];

    foreach ($productIds as $productId) {
        $query = "DELETE FROM product WHERE id = '$productId'";
        $query_run = mysqli_query($conn, $query);
    }

    if ($query_run) {
        header('Location: index2.php');
    } else {
        header('Location: index2.php');
    }
} else {
    header('Location: index2.php');
}
?>
