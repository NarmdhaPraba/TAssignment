<!DOCTYPE html>
<html>
  <head>
    <title>Add Product</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
  </head>
  <body>
    <div class="header">
      <h1>Add Product</h1>
      <div class="header-buttons">
     
      <a href="index2.php" class="btn btn-outline-primary">Cancel</a>
      </div>
    </div>
    <div class="header-line"></div>
    <div class="container mx-auto">
    <form action="prod_a2.php" id="add-product-form" class="form-control w-50 mx-auto" enctype="multipart/form-data" method="post">
    
      <label for="sku-input">SKU:</label>
      <input type="text" id="SKU" name="SKU" required><br>

      <label for="name-input">Name:</label>
      <input type="text" id="Name" name="Name" required><br>

      <label for="price-input">Price:</label>
      <input type="text" id="Price" name="Price" required><br>

      <label for="productType">Product Type:</label>
      <select id="productType">
      <option value="" >Choose your category</option>
        <option>DVD</option>
        <option>BOOK</option>
        <option>FURNITURE</option>
      </select>
       
    <div id="dvd-form" style="display: none;">
      <label for="size-input">Size (MB):</label>  
      <input type="text" id="Size" name="Size"><br>
    </div>
    <div id="book-form" style="display: none;">
      <label for="Weight-input">Weight (KG):</label>
      <input type="text" id="Weight" name="Weight"><br>
    </div>
    <div id="furniture-form" style="display: none;">
      <label for="Height-input">Height(CM):</label> 
       <input type="text" id="Height" name="Height"><br>
      <label for="Width-input">Width(CM):</label>
      <input type="text" id="Width" name="Width"><br>
      <label for="Lenght-input">Lenght(CM):</label>
      <input type="text" id="Length" name="Length"><br>
      
    </div>
<br>
    <button type="submit" id="btnSubmit" name="btnSubmit" value="post" onclick="myFunction()">Add product </button> 
    <script>
function myFunction() {
  alert("ITEM ADDED");
}
</script>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      $(document).ready(function() {
        // Event handler for product type change
        $('#productType').change(function() {
          var selectedValue = $(this).val();
          if (selectedValue === 'DVD') {
            $('#dvd-form').show();
          } else {
            $('#dvd-form').hide();
          }
          if (selectedValue === 'BOOK') {
            $('#book-form').show();
          } else {
            $('#book-form').hide();
          }
          if (selectedValue === 'FURNITURE') {
            $('#furniture-form').show();
          } else {
            $('#furniture-form').hide();
          }
          
        });

   
      });
    
    </script>
 
</form>

   
  </body>
</html>
