<?php

session_start();

use JetBrains\PhpStorm\Internal\PhpStormStubsElementAvailable;

$host = "localhost";
$username = "root";
$password = "";
$database = "product";

$conn = mysqli_connect($host, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetching products from the database
$query = "SELECT SKU, Name,id, Price, Size, Weight, Height, Width, Length FROM product WHERE SKU IS NOT NULL AND Name IS NOT NULL AND Price IS NOT NULL AND Size IS NOT NULL AND Weight IS NOT NULL AND Height IS NOT NULL AND Width IS NOT NULL AND Length IS NOT NULL ORDER BY id DESC";
$result = mysqli_query($conn, $query);
$products = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Closing the database connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Product List</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    

    
  </head>
  <body>
    <div class="header">
      <h1>Product List</h1>
      <div class="header-buttons">
      <button id="add-button"><a href="addproduct.php">ADD</a></button>

        <button id="mass-delete-button" class="N" 
        >MASS DELETE</button>
      </div>
    </div>
    <div class="header-line"></div>
    
    <div id="product-container">
      <!-- Product boxes will be dynamically added here -->
    </div>
    <title>Product Display</title>
    <style>
        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .box {
      width: 23%;
      height: 300px;
      margin-bottom: 30px;
      background-color: #ccc;
      border: 1px solid #999;
      box-sizing: border-box;
      margin-left: auto;
      position: relative
    }
    .checkbox {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        
    </style>

    <div class="container">
   
        <?php foreach ($products as $product) : ?>
            <div class="box">
                <!-- <input type="checkbox" class="checkbox"> -->
                <input type="checkbox" class="checkbox" value="<?php echo $product['id']; ?>">
                <h3><?php echo $product['Name']; ?></h3>
                <p>SKU: <?php echo $product['SKU']; ?></p>
                <?php if ($product['Price'] !== null) : ?>
                    <p>Price: $<?php echo $product['Price']; ?></p>
                <?php endif; ?>
                <?php if ($product['Size'] !== null) : ?>
                    <p>Size: <?php echo $product['Size']; ?>Kg</p>
                <?php endif; ?>
                <?php if ($product['Weight'] !== null) : ?>
                    <p>Weight: <?php echo $product['Weight']; ?></p>
                <?php endif; ?>
                <?php if ($product['Height'] !== null) : ?>
                    <p>Height: <?php echo $product['Height']; ?></p>
                <?php endif; ?>
                <?php if ($product['Width'] !== null) : ?>
                    <p>Width: <?php echo $product['Width']; ?></p>
                <?php endif; ?>
                <?php if ($product['Length'] !== null) : ?>
                    <p>Length: <?php echo $product['Length']; ?></p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        const massDeleteButton = document.getElementById('mass-delete-button');
        const checkboxes = document.querySelectorAll('.checkbox');

        massDeleteButton.addEventListener('click', () => {      


            const productIds = [];

            checkboxes.forEach(checkbox => {
                if (checkbox.checked) {
                    productIds.push(checkbox.value);
                }
            });

            if (productIds.length > 0) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'deleteprod.php';

                productIds.forEach(productId => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'product_ids[]';
                    input.value = productId;
                    form.appendChild(input);
                });

                document.body.appendChild(form);
                form.submit();
            }
        });
    </script>
</body>

</html>